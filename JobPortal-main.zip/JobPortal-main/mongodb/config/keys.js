module.exports = {
    mongoURI: "[Your Mongo DB connection string]",
    secretOrKey: "secret"
};
