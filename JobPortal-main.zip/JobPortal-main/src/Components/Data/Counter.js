const counter = [
	{
		value:"42",
		desc:"Jobs Posted"
	},
	{
		value:"20",
		desc:"Jobs Filled"
	},
	{
		value:"67",
		desc:"Companies"
	},
	{
		value:"80",
		desc:"Members"
	}
];

export default counter; 
