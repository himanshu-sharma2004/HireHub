const jobs=[
	{
		id: 1, 
		logo: "https://dofonline.co.uk/wp-content/uploads/2018/07/Deutsche-Bank-logo.jpg",
		role: "Data Analyst",
		company: "Deutsche Bank",
		loc: "Pune, Maharashtra"
	},
	{
		id: 2, 
		logo: "https://i2.wp.com/techsyndrome.in/wp-content/uploads/2018/01/nvidia-logo-square.png.imgw_.960.540.jpg?",
		role: "System Software Engineer",
		company: "Nvidia",
		loc: "Bangalore, India"
	},
	{
		id: 3, 
		logo: "https://pipap.sprep.org/sites/default/files/credit_suisse.jpg",
		role: "Web Designer / Developer",
		company: "Credit Suisse",
		loc: "Pune, Maharashtra"
	},
	{
		id: 4, 
		logo: "https://s.abcnews.com/images/Technology/ht_google_lb_150901_16x9_992.jpg",
		role: "Data Scientist",
		company: "Google",
		loc: "Hyderabad, India"
	},
	{
		id: 5, 
		logo: "https://gbatemp.net/attachments/184731/",
		role: "Marketing Director",
		company: "Amazon",
		loc: "Mumbai, Maharashtra"
	},
	{
		id: 6, 
		logo: "https://www.ccsinsight.com/images/blog/2018/03/IBM_logo_l.png",
		role: "UI / UX Designer",
		company: "IBM",
		loc: "Pune, Maharashtra"
	},
	{
		id: 7, 
		logo: "http://allvectorlogo.com/img/2017/03/deutsche-bank-logo.png",
		role: "Data Analyst",
		company: "Deutsche Bank",
		loc: "Pune, Maharashtra"
	},
	{
		id: 8, 
		logo: "https://i2.wp.com/techsyndrome.in/wp-content/uploads/2018/01/nvidia-logo-square.png.imgw_.960.540.jpg?",
		role: "System Software Engineer",
		company: "Nvidia",
		loc: "Bangalore, India"
	},
	{
		id: 9, 
		logo: "https://pipap.sprep.org/sites/default/files/credit_suisse.jpg",
		role: "Web Designer / Developer",
		company: "Credit Suisse",
		loc: "Pune, Maharashtra"
	},
	{
		id: 10, 
		logo: "https://s.abcnews.com/images/Technology/ht_google_lb_150901_16x9_992.jpg",
		role: "Data Scientist",
		company: "Google",
		loc: "Hyderabad, India"
	},
	{
		id: 11, 
		logo: "https://gbatemp.net/attachments/184731/",
		role: "Marketing Director",
		company: "Amazon",
		loc: "Mumbai, Maharashtra"
	},
	{
		id: 12, 
		logo: "https://www.ccsinsight.com/images/blog/2018/03/IBM_logo_l.png",
		role: "UI / UX Designer",
		company: "IBM",
		loc: "Pune, Maharashtra"
	}
];


export default jobs;